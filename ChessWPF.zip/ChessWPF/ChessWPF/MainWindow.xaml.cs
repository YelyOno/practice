﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using ChessWPF.MVVM.MODELS;

namespace ChessWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Board? board = null;
        string pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/alpha/";
        string firstCellColor = "#FFF4DF", secondCellColor = "#96785B";
        public MainWindow()
        {
            InitializeComponent();
            stylesComboBox.ItemsSource = new ChessStyle[]
            {
                new ChessStyle{Name = "adventurer"},
                new ChessStyle{Name = "alpha"},
                new ChessStyle{Name = "berlin"},
                new ChessStyle{Name = "cardinal"},
                new ChessStyle{Name = "cases"},
                new ChessStyle{Name = "cheq"},
                new ChessStyle{Name = "chess_samara"},
                new ChessStyle{Name = "chess24"},
                new ChessStyle{Name = "chess7"},
                new ChessStyle{Name = "chesscom"},
                new ChessStyle{Name = "chessnut"},
            };
            
        }
        private void stylesComboBox_SelectedStyle(object sender, SelectionChangedEventArgs e)
        {
            if (((ComboBox)sender).SelectedValue.ToString() == "alpha"){
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/alpha/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "adventurer"){
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/adventurer/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "berlin")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/berlin/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "cardinal")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/cardinal/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "cases")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/cases/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "cheq")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/cheq/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "chess_samara")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/chess_samara/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "chess24")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/chess24/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "chess7")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/chess7/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "chesscom")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/chesscom/";
            }
            else if (((ComboBox)sender).SelectedValue.ToString() == "chessnut")
            {
                pathToTheStyleOfChessPiece = "pack://application:,,,/RESOURCES/Images/ChessPieceStyles/chessnut/";
            }
            //проверка на то сгенерирована ли игровая доска,если нет то просто ее метод не вызовется
            if (board!=null)
            {
                board.UpdatePieceSources(pathToTheStyleOfChessPiece);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            board = new Board(pathToTheStyleOfChessPiece,firstCellColor,secondCellColor,ChessBoard);
        }

        private void boardsComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedItem = ((ComboBox)sender).SelectedItem as ComboBoxItem;
            var selectedText = (selectedItem?.Content as StackPanel)?.Children.OfType<TextBlock>().FirstOrDefault()?.Text;
            if (selectedText == "DEFAULT")
            {
                firstCellColor = "#FFF4DF";
                secondCellColor = "#96785B";
            }
            else if (selectedText == "ORANGE")
            {
                firstCellColor = "#FFE0B2";
                secondCellColor = "#D77D31";
            }
            else if (selectedText == "SEA GREEN")
            {
                firstCellColor = "#D3F1DF";
                secondCellColor = "#0A7075";
            }
            if (board != null)
            {
                board.UpdateBoardStyle(firstCellColor, secondCellColor);
            }
        }

    }
}