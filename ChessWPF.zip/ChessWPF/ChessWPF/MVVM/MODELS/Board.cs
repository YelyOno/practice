﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ChessWPF.MVVM.MODELS
{
    internal class Board
    {
        string _firstCellColor,_secondCellColor;
        public Board(string pathToTheStyleOfChessPiece,string firstCellColor,string secondCellColor,Grid chessBoardGrid)
        {
            _firstCellColor = firstCellColor;
            _secondCellColor = secondCellColor;
            InitializeBoard(pathToTheStyleOfChessPiece,firstCellColor,secondCellColor,chessBoardGrid);
        }
        private List<ChessPiece> existingChessPieces = new List<ChessPiece>();
        private List<ChessCell> chessCellsList = new List<ChessCell>();
        List<Move> validMoves = new List<Move>();
        //для генерации доски и многа чего(если true то белые фигуры снизу если false то белые фигуры сверху)
        private bool firstUserPlayingWhite = true;
        private bool IsWhiteMoving = true;
        private void InitializeBoard(string pathToTheStyleOfChessPiece, string firstCellColor, string secondCellColor, Grid chessBoardGrid)
        {
            //здесь цикл пробегается по ячейкам грида и разрисовывает его клетками
            for (int i = 0; i < chessBoardGrid.ColumnDefinitions.Count; i++)
            {
                for (int j = 0; j < chessBoardGrid.RowDefinitions.Count; j++)
                {
                    Border cell = new()
                    {
                        Background = (i + j) % 2 == 0 ? new SolidColorBrush((Color)ColorConverter.ConvertFromString(firstCellColor)) : new SolidColorBrush((Color)ColorConverter.ConvertFromString(secondCellColor)),
                    };
                    Grid.SetRow(cell, i);
                    Grid.SetColumn(cell, j);
                    chessBoardGrid.Children.Add(cell);
                    chessCellsList.Add(new ChessCell(new Position(i, j), cell));
                }
            }
            //здесь на доску добавляются фигуры(можно изменить это, например если игрок играет черными или можно добавить разные режимы)
            AddPiece((new ChessPiece(new Image(),new Position(7, 0), 'R', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(7, 7), 'R', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(),new Position(7, 1), 'N', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(7, 6), 'N', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(),new Position(7, 2), 'B', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(7, 5), 'B', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(),new Position(7, 3), 'Q', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(7, 4), 'Q', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(6, 0), 'P', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(6, 7), 'P', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(6, 1), 'P', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(6, 6), 'P', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(6, 2), 'P', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(6, 5), 'P', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(6, 3), 'P', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(6, 4), 'P', 'w')), pathToTheStyleOfChessPiece, chessBoardGrid);


            AddPiece((new ChessPiece(new Image(), new Position(0, 0), 'R', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(0, 7), 'R', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(0, 1), 'N', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(0, 6), 'N', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(0, 2), 'B', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(0, 5), 'B', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(0, 3), 'Q', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(0, 4), 'Q', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(1, 0), 'P', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(1, 7), 'P', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(1, 1), 'P', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(1, 6), 'P', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(1, 2), 'P', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(1, 5), 'P', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid);
            AddPiece((new ChessPiece(new Image(), new Position(1, 3), 'P', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid); AddPiece((new ChessPiece(new Image(), new Position(1, 4), 'P', 'b')), pathToTheStyleOfChessPiece, chessBoardGrid);
        }
        private void AddPiece(ChessPiece chesspiece,string path,Grid ChessBoardGrid)
        {
            chesspiece.Image = new()
            {
                Source = new BitmapImage(new Uri($"{path}{chesspiece.Color}{chesspiece.Type}.png")),
            };
            Grid.SetRow(chesspiece.Image, chesspiece.Position.Row);
            Grid.SetColumn(chesspiece.Image, chesspiece.Position.Column);
            ChessBoardGrid.Children.Add(chesspiece.Image);
            existingChessPieces.Add(chesspiece);
            chesspiece.Image.MouseLeftButtonDown += Image_MouseLeftButtonDown;
        }
        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Находим фигуру, которую выбрали
            var clickedImage = (Image)sender;
            var selectedPiece = existingChessPieces.FirstOrDefault(p => p.Image == clickedImage);
            if (selectedPiece != null)
            {
                validMoves.Clear();
                if (selectedPiece.Color == 'w' && firstUserPlayingWhite) 
                {
                    FindValidMoves(selectedPiece);
                    HighlightValidMoves();
                }
                else if(selectedPiece.Color == 'b' && !firstUserPlayingWhite)
                {
                    FindValidMoves(selectedPiece);
                    HighlightValidMoves();
                }
            }
        }

        private void FindValidMoves(ChessPiece selectedPiece)
        {
            // Здесь должна быть логика определения возможных ходов для каждой фигуры
            // Для примера рассмотрим простые правила для пешки
            if (selectedPiece.Type == 'P')
            {
                if (selectedPiece.Color == 'w') // Белый ходит вверх
                {
                    if (selectedPiece.Position.Row > 0)
                    {
                        // Проверяем возможность хода вперед на одну клетку
                        if (!HasPieceAtPosition(selectedPiece.Position.Row - 1, selectedPiece.Position.Column))
                        {
                            validMoves.Add(new Move(selectedPiece, new Position(selectedPiece.Position.Row - 1, selectedPiece.Position.Column)));
                        }

                        // Если пешка ещё не двигалась, проверяем возможность хода вперёд на две клетки
                        if (selectedPiece.Position.Row == 6 && !HasPieceAtPosition(selectedPiece.Position.Row - 2, selectedPiece.Position.Column))
                        {
                            validMoves.Add(new Move(selectedPiece, new Position(selectedPiece.Position.Row - 2, selectedPiece.Position.Column)));
                        }
                    }
                }
                else // Чёрная пешка ходит вниз
                {
                    if (selectedPiece.Position.Row < 7)
                    {
                        // Проверяем возможность хода вперед на одну клетку
                        if (!HasPieceAtPosition(selectedPiece.Position.Row + 1, selectedPiece.Position.Column))
                        {
                            validMoves.Add(new Move(selectedPiece, new Position(selectedPiece.Position.Row + 1, selectedPiece.Position.Column)));
                        }

                        // Если пешка ещё не двигалась, проверяем возможность хода вперёд на две клетки
                        if (selectedPiece.Position.Row == 1 && !HasPieceAtPosition(selectedPiece.Position.Row + 2, selectedPiece.Position.Column))
                        {
                            validMoves.Add(new Move(selectedPiece, new Position(selectedPiece.Position.Row + 2, selectedPiece.Position.Column)));
                        }
                    }
                }
            }
            // Аналогично добавляем логику для остальных фигур...
        }

        private bool HasPieceAtPosition(int row, int column)
        {
            return existingChessPieces.Any(p => p.Position.Row == row && p.Position.Column == column);
        }

        private void HighlightValidMoves()
        {
            // Снимаем предыдущую подсветку
            ResetCellBackgrounds();

            // Подсвечиваем клетки, соответствующие возможным ходам
            foreach (var move in validMoves)
            {
                var targetCell = chessCellsList.First(c => c.Position.Row == move.SecondPosition.Row && c.Position.Column == move.SecondPosition.Column);
                targetCell.Border.BorderBrush = Brushes.LightGreen;
                targetCell.Border.BorderThickness = new Thickness(4, 4, 4, 4);
            }
        }

        private void ResetCellBackgrounds()
        {
            foreach (var cell in chessCellsList)
            {
                cell.Border.BorderThickness = new Thickness(0,0,0,0);
            }
        }
        public void UpdatePieceSources(string newPath)
        {
            foreach (var item in existingChessPieces)
            {
                item.Image.Source = new BitmapImage(new Uri($"{newPath}{item.Color}{item.Type}.png"));
            }
        }
        public void UpdateBoardStyle(string firstColor,string secondColor)
        {
            _firstCellColor = firstColor;
            _secondCellColor = secondColor;
            foreach (var item in chessCellsList)
            {
                item.Border.Background = (item.Position.Row + item.Position.Column) % 2 == 0 ? new SolidColorBrush((Color)ColorConverter.ConvertFromString(firstColor)) : new SolidColorBrush((Color)ColorConverter.ConvertFromString(secondColor));
            }
        }
    }
}
