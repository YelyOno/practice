﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace ChessWPF.MVVM.MODELS
{
    internal class ChessCell
    {
        public ChessCell(Position Position,Border Border)
        {
            this.Position = Position;
            this.Border = Border;
        }
        public Position Position { get; set; }
        public Border Border { get; set; }
    }
}
