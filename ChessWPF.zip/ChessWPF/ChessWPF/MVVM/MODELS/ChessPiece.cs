﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace ChessWPF.MVVM.MODELS
{
    struct Position
    {
        public Position(int Row,int Column)
        {
            this.Row = Row;
            this.Column = Column;
        }
        public int Row { get; set; }
        public int Column { get; set; }
    }
    internal class ChessPiece
    {
        public ChessPiece(Image Image,Position Position,char Type,char Color)
        {
            this.Image = Image;
            this.Position = Position;
            this.Type = Type;
            this.Color = Color;
        }

        //position - хранит координаты фигуры на доске
        public Position Position { get; set; }
        //здесь свойства содержат одну букву - тип(R, N,P и др),а цвет(w или b), а потом эти значения подставляются в ссылку
        public char Type { get; set; }
        public char Color { get; set; }
        public Image Image { get; set; }


    }
}
