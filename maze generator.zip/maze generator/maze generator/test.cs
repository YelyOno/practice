﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace maze_generator
{
    internal class Test
    {

        public void Testim()
        {
            while (true)
            {
                Random rnd = new Random();
                int randIndex = rnd.Next(0, 3);
                Console.Write(randIndex + " ");
            }
        }
    }
}
