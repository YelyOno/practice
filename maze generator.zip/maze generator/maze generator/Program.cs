﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace maze_generator
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
           Maze maze = new Maze();
           maze.introduction();
           
            while (true)
            {
                
                Console.Clear();
                maze.Generate();
                maze.enableToMove = true;
                maze.didThePlayerWin = false;
                while (maze.enableToMove == true)
                {
                    maze.FindLegalMoves();
                    if (maze.enableToMove == false)
                    {
                        break;
                    }
                    maze.Move();

                }
                maze.GenStartAndFinishCell(); 
                while (maze.didThePlayerWin == false)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine(" __       __  ______  ________ ________       ______   ______  __       __ ________      \r\n|  \\     /  \\/      \\|        \\        \\     /      \\ /      \\|  \\     /  \\        \\     \r\n| ▓▓\\   /  ▓▓  ▓▓▓▓▓▓\\\\▓▓▓▓▓▓▓▓ ▓▓▓▓▓▓▓▓    |  ▓▓▓▓▓▓\\  ▓▓▓▓▓▓\\ ▓▓\\   /  ▓▓ ▓▓▓▓▓▓▓▓     \r\n| ▓▓▓\\ /  ▓▓▓ ▓▓__| ▓▓   /  ▓▓| ▓▓__        | ▓▓ __\\▓▓ ▓▓__| ▓▓ ▓▓▓\\ /  ▓▓▓ ▓▓__         \r\n| ▓▓▓▓\\  ▓▓▓▓ ▓▓    ▓▓  /  ▓▓ | ▓▓  \\       | ▓▓|    \\ ▓▓    ▓▓ ▓▓▓▓\\  ▓▓▓▓ ▓▓  \\        \r\n| ▓▓\\▓▓ ▓▓ ▓▓ ▓▓▓▓▓▓▓▓ /  ▓▓  | ▓▓▓▓▓       | ▓▓ \\▓▓▓▓ ▓▓▓▓▓▓▓▓ ▓▓\\▓▓ ▓▓ ▓▓ ▓▓▓▓▓        \r\n| ▓▓ \\▓▓▓| ▓▓ ▓▓  | ▓▓/  ▓▓___| ▓▓_____     | ▓▓__| ▓▓ ▓▓  | ▓▓ ▓▓ \\▓▓▓| ▓▓ ▓▓_____      \r\n| ▓▓  \\▓ | ▓▓ ▓▓  | ▓▓  ▓▓    \\ ▓▓     \\     \\▓▓    ▓▓ ▓▓  | ▓▓ ▓▓  \\▓ | ▓▓ ▓▓     \\     \r\n \\▓▓      \\▓▓\\▓▓   \\▓▓\\▓▓▓▓▓▓▓▓\\▓▓▓▓▓▓▓▓      \\▓▓▓▓▓▓ \\▓▓   \\▓▓\\▓▓      \\▓▓\\▓▓▓▓▓▓▓▓     \rby GREGORY DIBILOV\n                                                                                         \r\n                                                                                         \r\n                                                                                         \r\n");
                    Console.ResetColor();
                    maze.Print();
                
                    maze.PlayerMove();
                    if (maze.didThePlayerWin == true)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine(" __       __  ______  ________ ________       ______   ______  __       __ ________      \r\n|  \\     /  \\/      \\|        \\        \\     /      \\ /      \\|  \\     /  \\        \\     \r\n| ▓▓\\   /  ▓▓  ▓▓▓▓▓▓\\\\▓▓▓▓▓▓▓▓ ▓▓▓▓▓▓▓▓    |  ▓▓▓▓▓▓\\  ▓▓▓▓▓▓\\ ▓▓\\   /  ▓▓ ▓▓▓▓▓▓▓▓     \r\n| ▓▓▓\\ /  ▓▓▓ ▓▓__| ▓▓   /  ▓▓| ▓▓__        | ▓▓ __\\▓▓ ▓▓__| ▓▓ ▓▓▓\\ /  ▓▓▓ ▓▓__         \r\n| ▓▓▓▓\\  ▓▓▓▓ ▓▓    ▓▓  /  ▓▓ | ▓▓  \\       | ▓▓|    \\ ▓▓    ▓▓ ▓▓▓▓\\  ▓▓▓▓ ▓▓  \\        \r\n| ▓▓\\▓▓ ▓▓ ▓▓ ▓▓▓▓▓▓▓▓ /  ▓▓  | ▓▓▓▓▓       | ▓▓ \\▓▓▓▓ ▓▓▓▓▓▓▓▓ ▓▓\\▓▓ ▓▓ ▓▓ ▓▓▓▓▓        \r\n| ▓▓ \\▓▓▓| ▓▓ ▓▓  | ▓▓/  ▓▓___| ▓▓_____     | ▓▓__| ▓▓ ▓▓  | ▓▓ ▓▓ \\▓▓▓| ▓▓ ▓▓_____      \r\n| ▓▓  \\▓ | ▓▓ ▓▓  | ▓▓  ▓▓    \\ ▓▓     \\     \\▓▓    ▓▓ ▓▓  | ▓▓ ▓▓  \\▓ | ▓▓ ▓▓     \\     \r\n \\▓▓      \\▓▓\\▓▓   \\▓▓\\▓▓▓▓▓▓▓▓\\▓▓▓▓▓▓▓▓      \\▓▓▓▓▓▓ \\▓▓   \\▓▓\\▓▓      \\▓▓\\▓▓▓▓▓▓▓▓     \rby GREGORY DIBILOV\n                                                                                         \r\n                                                                                         \r\n                                                                                         \r\n");
                        Console.ResetColor();
                        maze.Print();
                        Console.WriteLine("вы победили!!!");
                        Console.ReadKey();
                    }
                }
            }
           
        }
    }
}
