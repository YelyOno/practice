﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;

namespace maze_generator
{
    internal class Maze
    {
        private byte width;
        private byte length;
        private char[,] mazeArray = null;
        Random rnd = new Random();

        //счетчик для элементов массива возможных ходов
        private int counter = 0;

        //массив лабиринта который отвечает за цвет(0 - белый(клетка прохода) 1 - желтый(клетка стенки))
        private int[,] mazeArrayColor = null;
        private int firstIndex, secondIndex,initialFirstIndex,initialSecondIndex,firstGreenCellIndex,secondGreenCellIndex;
        // массив ходов(1 элемент будет содержать 2 цифры которые будут конвертироваться в индексы)
        
        private string[] initialPositionOfCell = null;
        private int[] position = null;
        public bool enableToMove = true;
        public bool didThePlayerWin = false;

        /// <summary>
        ///генерирует лабиринт
        /// </summary>
        public void Generate()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            //здесь пользователь вводит длину лабиринта
            while (true)
            {
                
                Console.WriteLine(">>введите длину лабиринта\n>>от 5 до 99\n>>длина обязательно должна быть нечетной");

                if (byte.TryParse(Console.ReadLine(), out byte result))
                {
                    length = result;
                    if (length >= 5 && length <= 99 && length % 2 != 0)
                    {
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine(">>вы ввели неверное значение");
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine(">>вы ввели неверное значение");
                }
            }

            //здесь ширину
            while (true)
            {
                
                Console.WriteLine(">>введите ширину лабиринта\n>>от 5 до 99\n>>ширина обязательно должна быть нечетной");

                if (byte.TryParse(Console.ReadLine(), out byte result))
                {
                    width = result;
                    if (width >= 5 && width <= 99 && width % 2 != 0)
                    {
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine(">>вы ввели неверное значение");
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine(">>вы ввели неверное значение");
                }
            }
            Console.ResetColor();
            //здесь создается массив лабиринта с указанной выше размерностью
            mazeArray = new char[width, length];
            mazeArrayColor = new int[width, length];
            initialPositionOfCell = new string[width * length];
            position = new int[width * length];
            //здесь массив лабиринта заполняется клетками стенок
            for (int i = 0; i < mazeArray.GetLength(0); i++)
            {
                for (int k = 0; k < mazeArray.GetLength(1); k++)
                {
                    mazeArray[i, k] = '⬛';
                    mazeArrayColor[i, k] = 1;
                }
            }

            //здесь генерируется стартовая клетка
            while (true)
            {
                
                firstIndex = rnd.Next(1, width - 1);
                if (firstIndex % 2 != 0)
                {
                    secondIndex = rnd.Next(1, length - 1);
                    if (secondIndex % 2 != 0)
                    {
                        break;
                    }
                }
            }

            //здесь координаты этой стартовой клетки заносятся в массив
            mazeArrayColor[firstIndex, secondIndex] = 0;

        }


        /// <summary>
        /// выводит лабиринт в консоль
        /// </summary>
        public void Print()
        {
            if (mazeArray != null)
            {
                for (int i = 0; i < mazeArray.GetLength(0); i++)
                {
                    Console.Write("|");

                    for (int j = 0; j < mazeArray.GetLength(1); j++)
                    {
                        if (mazeArrayColor[i, j] == 0)
                        {
                            ChangeColor(mazeArray[i, j], 0);
                        }
                        else if (mazeArrayColor[i, j] == 1)
                        {
                            ChangeColor(mazeArray[i, j], 6);
                        }
                        else if (mazeArrayColor[i, j] == 2)
                        {
                            ChangeColor(mazeArray[i, j], 10);
                        }
                        else if (mazeArrayColor[i, j] == 3)
                        {
                            ChangeColor(mazeArray[i, j], 4);
                        }
                        Console.OutputEncoding = Encoding.UTF8;
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("лабиринт еще не сгенерирован");
            }

            void ChangeColor(object square, int color)
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.ForegroundColor = (ConsoleColor)color;
                Console.Write(square);
                Console.ResetColor();
            }
        }

        public void FindLegalMoves()
        {
           counter = 0;
            //здесь перебирается каждый элемент массива чтобы найти возможные ходы для генерации лабиринта
            for (firstIndex = 1; firstIndex < mazeArray.GetLength(0); firstIndex++)
            {
                for (secondIndex = 1; secondIndex < mazeArray.GetLength(1); secondIndex++)
                {
                    //здесь проверяется нечетность клетки
                    if (firstIndex % 2 != 0 && secondIndex % 2 != 0 && mazeArrayColor[firstIndex, secondIndex] == 0)
                    {
                        //проверка возможности пойти вверх
                        if (firstIndex - 2 > 0 && mazeArrayColor[firstIndex - 2, secondIndex] == 1)
                        {
                            //здесь в стринг массив возможных ходов заносятся два индекса(которые потом будут конвертированы обратно)
                            
                            initialPositionOfCell[counter] = $"{firstIndex}" + " " + $"{secondIndex}";
                            
                            position[counter] = 1;
                            counter++;
                        }

                        //проверка возможности пойти вниз
                        if (firstIndex + 2 <= width - 1 && mazeArrayColor[firstIndex + 2, secondIndex] == 1)
                        {
                            
                            initialPositionOfCell[counter] = $"{firstIndex}" + " " + $"{secondIndex}";
                           
                            position[counter] = 2;
                            counter++;
                        }

                        //проверка возможности пойти влево
                        if (secondIndex - 2 > 0 && mazeArrayColor[firstIndex, secondIndex - 2] == 1)
                        {
                            
                            initialPositionOfCell[counter] = $"{firstIndex}" + " " + $"{secondIndex}";
                            
                            position[counter] = 3;
                            counter++;
                        }

                        //проверка возможности пойти вправо
                        if (secondIndex + 2 <= length - 1 && mazeArrayColor[firstIndex, secondIndex + 2] == 1)
                        {
                            initialPositionOfCell[counter] = $"{firstIndex}" + " " + $"{secondIndex}";
                          
                            position[counter] = 4;
                            counter++;
                        }
                    }
                }
            }
            if (counter == 0)
            {
                enableToMove = false;
            }
        }

        public void Move()
        {
            int randIndex;
            string allMove = " ";
            string firstStr = " ";
            string secondStr = " ";
            
            randIndex = rnd.Next(0, counter);
            allMove = initialPositionOfCell[randIndex];
            for (int i = 0; i < allMove.Length; i++)
            {
                if (allMove[i] == ' ')
                {
                    for (int j = 0; j < i; j++)
                    {
                        firstStr += allMove[j];
                    }
                    for (int k = i + 1; k < allMove.Length; k++)
                    {
                        secondStr += allMove[k];
                    }
                }
            }
            initialFirstIndex = int.Parse(firstStr);
            initialSecondIndex = int.Parse(secondStr);

            
            //здесь узнается направление 1-вверх 2-вниз 3-влево 4-вправо
            if (position[randIndex] == 1)
            {
                mazeArrayColor[initialFirstIndex - 1, initialSecondIndex] = 0;
                mazeArrayColor[initialFirstIndex - 2, initialSecondIndex] = 0;
            }
            else if (position[randIndex] == 2)
            {
                mazeArrayColor[initialFirstIndex + 1, initialSecondIndex] = 0;
                mazeArrayColor[initialFirstIndex + 2, initialSecondIndex] = 0;
            }
           
            else if (position[randIndex] == 3)
            {
                mazeArrayColor[initialFirstIndex, initialSecondIndex - 1] = 0;
                mazeArrayColor[initialFirstIndex, initialSecondIndex - 2] = 0;
            }
           
            else if (position[randIndex] == 4)
            {

                mazeArrayColor[initialFirstIndex, initialSecondIndex + 1] = 0;
                mazeArrayColor[initialFirstIndex, initialSecondIndex + 2] = 0;
            }
            
        }

        public void GenStartAndFinishCell()
        {
            int startCell,finishCell;

            //здесь выбирается направление клетки старта и клетки финиша(0-по вертикали 1-по горизонтали)
            //т.е. если выпал 0 то в самом первом столбце(слева) случайно генерируется клетка старта а в самом последнем столбце(справа) клетка финиша
            //а если выпал 1 то в самой первой строке(сверху) случайно генерируется клетка старта а в самой последней строке(снизу) генерируется клетка финиша
            int direction = rnd.Next(0,2);
            if (direction == 0)
            {
                while (true)
                {
                    startCell = rnd.Next(1, width - 1);
                    if (mazeArrayColor[startCell,1] == 0)
                    {
                        finishCell = rnd.Next(1, width - 1);
                        if ( mazeArrayColor[finishCell,length - 2] == 0)
                        {
                            mazeArrayColor[startCell,0] = 2;
                            mazeArrayColor[finishCell,length - 1] = 3;

                            firstGreenCellIndex = startCell;
                            secondGreenCellIndex = 0;
                            break;
                        }
                    }
                }
               
            }
            else if (direction == 1)
            {
                while (true)
                {
                    startCell = rnd.Next(1, length - 1);
                    if (mazeArrayColor[1, startCell] == 0)
                    {
                        finishCell = rnd.Next(1, length - 1);
                        if (mazeArrayColor[width - 2,finishCell] == 0)
                        {
                            mazeArrayColor[0, startCell] = 2;
                            mazeArrayColor[width - 1,finishCell] = 3;

                            firstGreenCellIndex = 0;
                            secondGreenCellIndex = startCell;
                            break;
                        }
                    }
                }
            }
        }

        public void PlayerMove()
        {
            while(true)
            {
                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.W:
                        if (firstGreenCellIndex - 1 >= 0 && mazeArrayColor[firstGreenCellIndex - 1, secondGreenCellIndex] == 0 && firstGreenCellIndex - 1 >= 0)
                        {
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex] = 0;
                            mazeArrayColor[firstGreenCellIndex - 1, secondGreenCellIndex] = 2;
                            firstGreenCellIndex--;
                            break;
                        }
                        else if (firstGreenCellIndex - 1 >= 0 && mazeArrayColor[firstGreenCellIndex - 1, secondGreenCellIndex] == 3)
                        {
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex] = 0;
                            mazeArrayColor[firstGreenCellIndex - 1, secondGreenCellIndex] = 2;
                            didThePlayerWin = true;
                            firstGreenCellIndex--;
                            break;
                        }
                        else
                        {
                            continue;
                        }
                        

                    case ConsoleKey.S:
                        if (firstGreenCellIndex + 1 <= width && mazeArrayColor[firstGreenCellIndex + 1, secondGreenCellIndex] == 0)
                        {
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex] = 0;
                            mazeArrayColor[firstGreenCellIndex + 1, secondGreenCellIndex] = 2;
                            firstGreenCellIndex++;
                            break;
                        }
                        else if (firstGreenCellIndex + 1 <= width && mazeArrayColor[firstGreenCellIndex + 1, secondGreenCellIndex] == 3)
                        {
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex] = 0;
                            mazeArrayColor[firstGreenCellIndex + 1, secondGreenCellIndex] = 2;
                            didThePlayerWin = true;
                            firstGreenCellIndex++;
                            break;
                        }
                        else
                        {
                            continue;
                        }
                        

                    case ConsoleKey.A:
                        if (secondGreenCellIndex - 1 >= 0 && mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex - 1] == 0)
                        {
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex] = 0;
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex - 1] = 2;
                            secondGreenCellIndex--;
                            break;
                        }
                        else if (secondGreenCellIndex - 1 >= 0 && mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex - 1] == 3)
                        {
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex] = 0;
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex - 1] = 2;
                            didThePlayerWin = true;
                            secondGreenCellIndex--;
                            break;
                        }
                        else
                        {
                            continue;
                        }
                        

                    case ConsoleKey.D:
                        if (secondGreenCellIndex + 1 <= length && mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex + 1] == 0)
                        {
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex] = 0;
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex + 1] = 2;
                            secondGreenCellIndex++;
                            break;
                        }
                        else if (secondGreenCellIndex + 1 <= length && mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex + 1] == 3)
                        {
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex] = 0;
                            mazeArrayColor[firstGreenCellIndex, secondGreenCellIndex + 1] = 2;
                            didThePlayerWin = true;
                            secondGreenCellIndex++;
                            break;
                        }
                        else
                        {
                            continue;
                        }
                        default:
                        {
                            continue;
                        }
                }
                break;
            }
            
        }

        public void introduction()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine(" __       __  ______  ________ ________       ______   ______  __       __ ________      \r\n|  \\     /  \\/      \\|        \\        \\     /      \\ /      \\|  \\     /  \\        \\     \r\n| ▓▓\\   /  ▓▓  ▓▓▓▓▓▓\\\\▓▓▓▓▓▓▓▓ ▓▓▓▓▓▓▓▓    |  ▓▓▓▓▓▓\\  ▓▓▓▓▓▓\\ ▓▓\\   /  ▓▓ ▓▓▓▓▓▓▓▓     \r\n| ▓▓▓\\ /  ▓▓▓ ▓▓__| ▓▓   /  ▓▓| ▓▓__        | ▓▓ __\\▓▓ ▓▓__| ▓▓ ▓▓▓\\ /  ▓▓▓ ▓▓__         \r\n| ▓▓▓▓\\  ▓▓▓▓ ▓▓    ▓▓  /  ▓▓ | ▓▓  \\       | ▓▓|    \\ ▓▓    ▓▓ ▓▓▓▓\\  ▓▓▓▓ ▓▓  \\        \r\n| ▓▓\\▓▓ ▓▓ ▓▓ ▓▓▓▓▓▓▓▓ /  ▓▓  | ▓▓▓▓▓       | ▓▓ \\▓▓▓▓ ▓▓▓▓▓▓▓▓ ▓▓\\▓▓ ▓▓ ▓▓ ▓▓▓▓▓        \r\n| ▓▓ \\▓▓▓| ▓▓ ▓▓  | ▓▓/  ▓▓___| ▓▓_____     | ▓▓__| ▓▓ ▓▓  | ▓▓ ▓▓ \\▓▓▓| ▓▓ ▓▓_____      \r\n| ▓▓  \\▓ | ▓▓ ▓▓  | ▓▓  ▓▓    \\ ▓▓     \\     \\▓▓    ▓▓ ▓▓  | ▓▓ ▓▓  \\▓ | ▓▓ ▓▓     \\     \r\n \\▓▓      \\▓▓\\▓▓   \\▓▓\\▓▓▓▓▓▓▓▓\\▓▓▓▓▓▓▓▓      \\▓▓▓▓▓▓ \\▓▓   \\▓▓\\▓▓      \\▓▓\\▓▓▓▓▓▓▓▓     \rby GREGORY DIBILOV\n                                                                                         \r\n                                                                                         \r\n                                                                                         \r\n");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(">>нажмите любую клавишу чтобы начать");
            Console.ResetColor();
            Console.ReadKey();
            
        }
    }
}
